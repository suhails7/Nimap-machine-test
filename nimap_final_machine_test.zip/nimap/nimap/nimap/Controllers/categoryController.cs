﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using nimap.Data;
using nimap.Models;
using nimap.Models.domain;
using X.PagedList;

namespace nimap.Controllers
{
    public class categoryController : Controller
    {
        private readonly nimapContext nimapContext;

        public categoryController(nimapContext nimapContext)
        {
            this.nimapContext = nimapContext;
        }
        [HttpGet]
        public IActionResult add()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> Index(int? page = 1)
        {
            if (page != null && page < 1)
            {
                page = 1;
            }
            const int pageSize = 10;
            var category = await nimapContext.Category.ToListAsync();
           // int pageNumber = page ?? 1;
            var pagedData = category.ToPagedList(page ?? 1, pageSize);
            // const int pageSize = 1;
            //if (pg<1)
            //    pg = 1;
            //int resCount = category.Count();
            //var pager = new pager(resCount, pg, pageSize);
            //int recSkip = (pg - 1) * pageSize;
            //var data = category.Skip(recSkip).Take(pager.PageSize).ToList();
            //this.ViewBag.Pager = pager;
            return View(pagedData);
        }

        [HttpPost]
        public async Task<IActionResult> add(AddCategoryViewModel addcategory)
        {
            var categroy = new Category()
            {
                CategoryId = Guid.NewGuid().ToString(),
                CategoryName = addcategory.CategoryName,
            };

            await nimapContext.Category.AddAsync(categroy);
            await nimapContext.SaveChangesAsync();
            return RedirectToAction("Index");
        }


        [HttpGet("category/view/{categoryid}")]

        public async Task<IActionResult> view(string categoryId)
        {
            Guid catid = new Guid(categoryId);
            var category = await nimapContext.Category.FirstOrDefaultAsync(x => x.CategoryId == categoryId);

            if (category != null)
            {

                var viewmodel = new UpdateCategoryViewModel()
                {
                    CategoryId = category.CategoryId,
                    CategoryName = category.CategoryName,
                };
                return View(viewmodel);
            }

            return RedirectToAction("Index");
        }
  
        [HttpPost]
        public async Task<IActionResult> view(UpdateCategoryViewModel updatecategory)
        {
            var category = await nimapContext.Category.FindAsync(updatecategory.CategoryId);
            if (category != null)
            {
                category.CategoryName = updatecategory.CategoryName;
                await nimapContext.SaveChangesAsync();
                return  RedirectToAction("Index");
            }
            return RedirectToAction("Index");

        }



        /*    //delete button
            [HttpGet]
            public ActionResult delete(Guid categoryId)
            {
                var obj = nimapContext.Category.Find();
                if (obj != null)
                {
                    return View(obj);
                }
                return RedirectToAction("Index");
            }

            */
        [HttpPost]
        public async Task<IActionResult> delete(UpdateCategoryViewModel updateCategoryViewModel)
        {
            var category = await nimapContext.Category.FindAsync(updateCategoryViewModel.CategoryId);
            if (category != null)
            {
                nimapContext.Category.Remove(category);
                await nimapContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
        [HttpGet("category/delete/{categoryid}")]
        public async Task<IActionResult> delete(string categoryid)
        {
            var category = await nimapContext.Category.FirstOrDefaultAsync(x => x.CategoryId == categoryid);
            if (category != null)
            {
                nimapContext.Category.Remove(category);
                await nimapContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}
