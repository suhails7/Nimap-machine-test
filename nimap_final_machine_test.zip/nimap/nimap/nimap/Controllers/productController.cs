﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using nimap.Data;
using nimap.Models.domain;
using X.PagedList;

namespace nimap_machine_test.Controllers
{
    public class productController : Controller
    {
        private readonly nimapContext nimapContext;

        public productController(nimapContext nimapContext)
        {
            this.nimapContext = nimapContext;
        }
        [HttpGet]
        public IActionResult add()
        {
            var categories = nimapContext.Category.ToList();
            var viewModel = new AddProductViewModel
            {
                Category = new SelectList(categories, "CategoryId", "CategoryName")
            };
            return View(viewModel);
        }



        [HttpGet]
        public async Task<IActionResult> Index(int? page = 1)
        {
            if (page != null && page < 1)
            {
                page = 1;
            }
            const int pageSize = 10;
            var product = await nimapContext.product.Include("Category").ToListAsync();
            // int pageNumber = page ?? 1;
            var pagedData = product.ToPagedList(page ?? 1, pageSize);
            return View(pagedData);
        }

        [HttpPost]
        public async Task<IActionResult> add(AddProductViewModel addproduct)
        {
            var cat = await nimapContext.Category.FirstOrDefaultAsync(x => x.CategoryId == addproduct.CategoryId);
            var product = new product()
            {
                ProductId = Guid.NewGuid().ToString(),
                ProductName = addproduct.ProductName,
                Category = cat
            };

            await nimapContext.product.AddAsync(product);
            await nimapContext.SaveChangesAsync();
            return RedirectToAction("Index");
        }


        [HttpGet("product/view/{productId}")]
        public async Task<IActionResult> view(string productId)
        {
            var product = await nimapContext.product.FirstOrDefaultAsync(x => x.ProductId == productId);
            if (product != null)
            {

                var viewmodel = new UpdateProductViewModel()
                {
                    ProductId = product.ProductId,
                    ProductName = product.ProductName ,
                };
                return View(viewmodel);
            }

            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> view(UpdateProductViewModel updateproduct)
        {
            var product = await nimapContext.product.FindAsync(updateproduct.ProductId);
            if (product != null)
            {
                product.ProductName = updateproduct.ProductName;
                await nimapContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");

        }


        [HttpPost]
        public async Task<IActionResult> delete(UpdateProductViewModel updateProductViewModel)
        {
            var product = await nimapContext.Category.FindAsync(updateProductViewModel.ProductId);
            if (product != null)
            {
                nimapContext.Category.Remove(product);
                await nimapContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
        [HttpGet("product/delete/{productid}")]
        public async Task<IActionResult> delete(string productId)
        {
            var product = await nimapContext.product.FirstOrDefaultAsync(x => x.ProductId == productId);
            if (product != null)
            {
                nimapContext.product.Remove(product);
                await nimapContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}
