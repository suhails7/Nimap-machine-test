﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace nimap.Models.domain
{
    public class Category
    {
        public Category()
        {
            products =new List<product>();
        }
        [Key]
        public string CategoryId { get; set; }
        public string CategoryName { get; set; }

        public List<product> products { get; set; }

    }

}
