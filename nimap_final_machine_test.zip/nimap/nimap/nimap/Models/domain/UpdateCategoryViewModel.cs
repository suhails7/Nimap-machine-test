﻿namespace nimap.Models.domain
{
    public class UpdateCategoryViewModel
    {
        public string CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
