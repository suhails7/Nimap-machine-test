﻿namespace nimap.Models.domain
{
    public class AddCategoryViewModel
    {
        public string CategoryName { get; set; }
    }
}
