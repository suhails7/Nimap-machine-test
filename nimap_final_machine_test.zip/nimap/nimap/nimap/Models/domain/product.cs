﻿using nimap.Models.domain;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace nimap.Models.domain
{
    public class product   {
        [Key]
        public string ProductId { get; set; }
        public string ProductName { get; set; } 
        public virtual Category Category { get; set; }
        //[ForeignKey("Category")]
        //public Guid CateID { get; set; }
    }
}