﻿namespace nimap.Models.domain
{
    public class UpdateProductViewModel
    {

        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public virtual Category Category { get; set; }
    }
}
