﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace nimap.Models.domain
{
    public class AddProductViewModel
    {
        public string ProductName { get; set;}
        public SelectList Category{ get; set; }
        public string CategoryId { get; set; }
    }
}
