﻿using Microsoft.EntityFrameworkCore;
using nimap.Models.domain;

namespace nimap.Data
{
    public class nimapContext : DbContext
    {
        public nimapContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<Category> Category{ get; set; }
        public DbSet<product> product { get; set; }
    }
}
